from database.database import cursor, conn



# ------------------------
# Get Next Serial
# ------------------------

def get_next_serial():

    cursor.execute(
        "SELECT MAX(serial_number) FROM inventory"
    )

    result = cursor.fetchone()[0]


    if result is None:
        return 1


    return result + 1



# ------------------------
# Add Card
# ------------------------

def add_card(telegram_id, card_id):

    serial = get_next_serial()


    cursor.execute("""
        INSERT INTO inventory
        (
            telegram_id,
            card_id,
            serial_number
        )

        VALUES (?, ?, ?)
    """, (
        telegram_id,
        card_id,
        serial
    ))


    conn.commit()


    return serial



# ------------------------
# Check Ownership
# ------------------------

def owns_card(telegram_id, card_id):

    cursor.execute("""
        SELECT *
        FROM inventory

        WHERE telegram_id = ?
        AND card_id = ?
    """, (
        telegram_id,
        card_id
    ))


    return cursor.fetchone() is not None



# ------------------------
# Get Inventory
# ------------------------

def get_inventory(telegram_id):

    cursor.execute("""
        SELECT
            card_id,
            serial_number

        FROM inventory

        WHERE telegram_id = ?

        ORDER BY obtained_at
    """, (
        telegram_id,
    ))


    return cursor.fetchall()