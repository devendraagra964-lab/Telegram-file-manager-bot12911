from database.database import cursor, conn



# ------------------------
# Add Card To Market
# ------------------------

def add_listing(
    seller_id,
    card_id,
    serial_number,
    price
):

    cursor.execute("""
        INSERT INTO market
        (
            seller_id,
            card_id,
            serial_number,
            price
        )

        VALUES (?, ?, ?, ?)
    """, (
        seller_id,
        card_id,
        serial_number,
        price
    ))

    conn.commit()



# ------------------------
# Get All Market Cards
# ------------------------

def get_market():

    cursor.execute("""
        SELECT
            market.id,
            cards.name,
            cards.series,
            cards.rarity,
            market.price,
            market.seller_id,
            market.serial_number

        FROM market

        JOIN cards

        ON market.card_id = cards.id
    """)

    return cursor.fetchall()



# ------------------------
# Get User Listings
# ------------------------

def get_user_market(user_id):

    cursor.execute("""
        SELECT
            market.id,
            cards.name,
            cards.rarity,
            market.price,
            market.card_id,
            market.serial_number

        FROM market

        JOIN cards

        ON market.card_id = cards.id

        WHERE market.seller_id = ?
    """, (
        user_id,
    ))

    return cursor.fetchall()



# ------------------------
# Get Single Listing
# ------------------------

def get_listing(listing_id):

    cursor.execute("""
        SELECT
            seller_id,
            card_id,
            serial_number,
            price

        FROM market

        WHERE id = ?
    """, (
        listing_id,
    ))

    return cursor.fetchone()



# ------------------------
# Remove Listing
# ------------------------

def remove_listing(listing_id):

    cursor.execute("""
        DELETE FROM market

        WHERE id = ?
    """, (
        listing_id,
    ))

    conn.commit()