from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from database.users import user_exists, create_user

router = Router()


@router.message(Command("start"))
async def start_command(message: Message):
    telegram_id = message.from_user.id
    username = message.from_user.username or message.from_user.first_name

    if not user_exists(telegram_id):
        create_user(telegram_id, username)

        await message.reply(
            "🎴 <b>Welcome to Otaku Arena!</b>\n\n"
            "✅ Account Created Successfully!\n"
            "🌀 Starting Chi: <b>5,000</b>\n\n"
            "Use /help to see all commands.",
            parse_mode="HTML"
        )
    else:
        await message.reply(
            "👋 <b>Welcome back to Otaku Arena!</b>",
            parse_mode="HTML"
        )