from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder

from database.market import (
    get_market,
    get_listing,
    remove_listing
)

from database.users import (
    get_chi,
    remove_chi,
    add_chi
)

from database.inventory import add_card

from database.database import cursor, conn


router = Router()


# ------------------------
# Market Buttons
# ------------------------

def market_buttons(cards):

    keyboard = InlineKeyboardBuilder()

    for card in cards:

        market_id = card[0]
        name = card[1]

        keyboard.button(
            text=f"🛒 Buy {name}",
            callback_data=f"buy_market_{market_id}"
        )

    keyboard.adjust(1)

    return keyboard.as_markup()


# ------------------------
# Confirm Buttons
# ------------------------

def confirm_buttons(market_id):

    keyboard = InlineKeyboardBuilder()

    keyboard.button(
        text="✅ Confirm",
        callback_data=f"confirm_buy_{market_id}"
    )

    keyboard.button(
        text="❌ Cancel",
        callback_data="cancel_buy"
    )

    keyboard.adjust(2)

    return keyboard.as_markup()


# ------------------------
# Market Command
# ------------------------

@router.message(Command("market"))
async def market_command(message: Message):

    cards = get_market()

    if not cards:

        await message.reply(
            "🛒 <b>Player Market</b>\n\n"
            "No cards are currently listed.",
            parse_mode="HTML"
        )

        return

    text = (
        "🛒 <b>Otaku Arena Player Market</b>\n"
        "━━━━━━━━━━━━━━\n\n"
    )

    for index, card in enumerate(cards, start=1):

        text += (
            f"{index}. 🎴 <b>{card[1]}</b>\n"
            f"📺 {card[2]}\n"
            f"⭐ {card[3]}\n"
            f"🌀 Price: {card[4]:,} Chi\n"
            f"🔢 Serial: #{card[6]:06d}\n\n"
        )

    await message.reply(
        text,
        reply_markup=market_buttons(cards),
        parse_mode="HTML"
    )


# ------------------------
# Buy Button
# ------------------------

@router.callback_query(
    lambda c: c.data.startswith("buy_market_")
)
async def buy_market_card(callback: CallbackQuery):

    market_id = int(
        callback.data.split("_")[2]
    )

    listing = get_listing(
        market_id
    )

    if not listing:

        await callback.answer(
            "❌ Card unavailable.",
            show_alert=True
        )

        return

    card_id = listing[1]
    price = listing[3]

    cursor.execute("""
        SELECT name, rarity
        FROM cards
        WHERE id = ?
    """, (
        card_id,
    ))

    card = cursor.fetchone()

    await callback.message.answer(
        "🛒 <b>Confirm Purchase</b>\n\n"
        f"🎴 {card[0]}\n"
        f"⭐ {card[1]}\n"
        f"🌀 Price: {price:,} Chi\n\n"
        "Are you sure?",
        reply_markup=confirm_buttons(market_id),
        parse_mode="HTML"
    )

    await callback.answer()


# ------------------------
# Confirm Buy
# ------------------------

@router.callback_query(
    lambda c: c.data.startswith("confirm_buy_")
)
async def confirm_buy(callback: CallbackQuery):

    market_id = int(
        callback.data.split("_")[2]
    )

    listing = get_listing(
        market_id
    )

    if not listing:

        await callback.answer(
            "❌ Listing expired.",
            show_alert=True
        )

        return

    seller_id = listing[0]
    card_id = listing[1]
    price = listing[3]

    buyer_id = callback.from_user.id

    if buyer_id == seller_id:

        await callback.answer(
            "❌ You cannot buy your own card.",
            show_alert=True
        )

        return

    if get_chi(buyer_id) < price:

        await callback.answer(
            "❌ Not enough Chi!",
            show_alert=True
        )

        return

    # Payment
    remove_chi(
        buyer_id,
        price
    )

    add_chi(
        seller_id,
        price
    )

    # Give card to buyer
    new_serial = add_card(
        buyer_id,
        card_id
    )

    # Remove listing
    remove_listing(
        market_id
    )

    conn.commit()

    cursor.execute("""
        SELECT name, rarity
        FROM cards
        WHERE id = ?
    """, (
        card_id,
    ))

    card = cursor.fetchone()

    await callback.message.answer(
        "✅ <b>Purchase Successful!</b>\n\n"
        f"🎴 {card[0]}\n"
        f"⭐ {card[1]}\n"
        f"🔢 Serial: #{new_serial:06d}\n\n"
        f"🌀 Spent: {price:,} Chi",
        parse_mode="HTML"
    )

    await callback.answer()


# ------------------------
# Cancel
# ------------------------

@router.callback_query(
    lambda c: c.data == "cancel_buy"
)
async def cancel_buy(callback: CallbackQuery):

    await callback.answer(
        "❌ Purchase cancelled."
    )