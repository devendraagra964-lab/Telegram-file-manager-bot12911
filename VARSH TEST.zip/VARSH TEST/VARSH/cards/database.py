cards = [
    {
        "id": 1,
        "name": "Son Goku",
        "series": "Dragon Ball",
        "rarity": "Mythical",
        "rating": "Infinity",
        "power": "Immeasurable",
        "ability": "Limitless Saiyan Potential",
        "card_number": "DB-001",
        "image": "images/dragon_ball/goku.png"
    }
]