from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from database.store import get_store
from database.users import get_chi, remove_chi
from database.inventory import add_card


router = Router()


@router.message(Command("buy"))
async def buy_command(message: Message):

    args = message.text.split()

    if len(args) < 3:
        await message.reply(
            "❌ Usage:\n\n"
            "/buy card <number>"
        )
        return


    item_type = args[1]
    item_number = int(args[2])


    store_items = get_store()


    if item_number > len(store_items):
        await message.reply(
            "❌ Item not found in today's store."
        )
        return


    item = store_items[item_number - 1]


    if item[0] != item_type:
        await message.reply(
            "❌ Wrong item type."
        )
        return


    price = item[2]

    telegram_id = message.from_user.id


    chi = get_chi(telegram_id)


    if chi < price:
        await message.reply(
            f"❌ Not enough Chi!\n\n"
            f"🌀 Required: {price:,}\n"
            f"🌀 Your Chi: {chi:,}"
        )
        return


    remove_chi(
        telegram_id,
        price
    )


    if item_type == "card":

        card_id = item[1]

        serial = add_card(
            telegram_id,
            card_id
        )


        await message.reply(
            "🎉 Card Purchased!\n\n"
            f"🔢 Serial: #{serial:06d}\n"
            f"🌀 Spent: {price:,} Chi"
        )


    else:

        await message.reply(
            "🎁 Item Purchased!"
        )