from datetime import datetime

from database.database import cursor, conn


# ------------------------
# User Functions
# ------------------------

def user_exists(telegram_id: int):
    cursor.execute(
        "SELECT telegram_id FROM users WHERE telegram_id=?",
        (telegram_id,)
    )
    return cursor.fetchone() is not None


def create_user(telegram_id: int, username: str):
    cursor.execute("""
        INSERT INTO users(
            telegram_id,
            username,
            chi,
            daily_rolls,
            last_roll_reset
        )
        VALUES(?,?,?,?,?)
    """, (
        telegram_id,
        username,
        5000,
        0,
        datetime.now().date().isoformat()
    ))

    conn.commit()


def get_user(telegram_id: int):

    reset_daily_rolls(telegram_id)

    cursor.execute("""
        SELECT
            telegram_id,
            username,
            chi,
            total_rolls,
            daily_rolls,
            last_daily,
            join_date
        FROM users
        WHERE telegram_id=?
    """, (telegram_id,))

    return cursor.fetchone()


# ------------------------
# Chi Functions
# ------------------------

def get_chi(telegram_id: int):

    cursor.execute(
        "SELECT chi FROM users WHERE telegram_id=?",
        (telegram_id,)
    )

    result = cursor.fetchone()

    return result[0] if result else 0


def add_chi(telegram_id: int, amount: int):

    cursor.execute("""
        UPDATE users
        SET chi=chi+?
        WHERE telegram_id=?
    """, (
        amount,
        telegram_id
    ))

    conn.commit()


def remove_chi(telegram_id: int, amount: int):

    current = get_chi(telegram_id)

    if current < amount:
        return False

    cursor.execute("""
        UPDATE users
        SET chi=chi-?
        WHERE telegram_id=?
    """, (
        amount,
        telegram_id
    ))

    conn.commit()

    return True


def set_chi(telegram_id: int, amount: int):

    cursor.execute("""
        UPDATE users
        SET chi=?
        WHERE telegram_id=?
    """, (
        amount,
        telegram_id
    ))

    conn.commit()


# ------------------------
# Total Rolls
# ------------------------

def add_roll(telegram_id: int):

    cursor.execute("""
        UPDATE users
        SET total_rolls=total_rolls+1
        WHERE telegram_id=?
    """, (telegram_id,))

    conn.commit()


def get_total_rolls(telegram_id: int):

    cursor.execute("""
        SELECT total_rolls
        FROM users
        WHERE telegram_id=?
    """, (telegram_id,))

    result = cursor.fetchone()

    return result[0] if result else 0


# ------------------------
# Daily Roll Limit
# ------------------------

def reset_daily_rolls(telegram_id: int):

    today = datetime.now().date().isoformat()

    cursor.execute("""
        SELECT last_roll_reset
        FROM users
        WHERE telegram_id=?
    """, (telegram_id,))

    data = cursor.fetchone()

    if not data:
        return

    if data[0] != today:

        cursor.execute("""
            UPDATE users
            SET
                daily_rolls=0,
                last_roll_reset=?
            WHERE telegram_id=?
        """, (
            today,
            telegram_id
        ))

        conn.commit()


def get_daily_rolls(telegram_id: int):

    reset_daily_rolls(telegram_id)

    cursor.execute("""
        SELECT daily_rolls
        FROM users
        WHERE telegram_id=?
    """, (telegram_id,))

    result = cursor.fetchone()

    return result[0] if result else 0


def can_roll(telegram_id: int):

    return get_daily_rolls(telegram_id) < 5


def add_daily_roll(telegram_id: int):

    reset_daily_rolls(telegram_id)

    cursor.execute("""
        UPDATE users
        SET daily_rolls=daily_rolls+1
        WHERE telegram_id=?
    """, (telegram_id,))

    conn.commit()


# ------------------------
# Inventory Stats
# ------------------------

def get_card_count(telegram_id: int):

    cursor.execute("""
        SELECT COUNT(*)
        FROM inventory
        WHERE telegram_id=?
    """, (telegram_id,))

    return cursor.fetchone()[0]


# ------------------------
# Daily Reward
# ------------------------

def get_last_daily(telegram_id: int):

    cursor.execute("""
        SELECT last_daily
        FROM users
        WHERE telegram_id=?
    """, (telegram_id,))

    result = cursor.fetchone()

    return result[0] if result else None


def set_last_daily(telegram_id: int):

    cursor.execute("""
        UPDATE users
        SET last_daily=?
        WHERE telegram_id=?
    """, (
        datetime.now().isoformat(),
        telegram_id
    ))

    conn.commit()