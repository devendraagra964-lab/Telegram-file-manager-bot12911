from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder

from database.daily_store import (
    daily_store_exists,
    generate_daily_store,
    get_daily_store
)

from database.database import cursor, conn
from database.users import get_chi, remove_chi
from database.inventory import add_card


router = Router()


# ------------------------
# Store Buttons
# ------------------------

def store_buttons(cards):

    keyboard = InlineKeyboardBuilder()

    for card in cards:

        store_id = card[0]
        name = card[1]

        keyboard.button(
            text=f"🛒 Buy {name}",
            callback_data=f"buy_daily_{store_id}"
        )

    keyboard.adjust(1)

    return keyboard.as_markup()


# ------------------------
# Store Command
# ------------------------

@router.message(Command("store"))
async def store_command(message: Message):

    if not daily_store_exists():

        generate_daily_store()

    cards = get_daily_store()

    if not cards:

        await message.reply(
            "🏪 Daily Store is empty."
        )

        return

    text = (
        "🏪 <b>Otaku Arena Daily Card Store</b>\n"
        "━━━━━━━━━━━━━━\n\n"
    )

    for index, card in enumerate(cards, start=1):

        text += (
            f"{index}. 🎴 <b>{card[1]}</b>\n"
            f"📺 {card[2]}\n"
            f"⭐ {card[3]}\n"
            f"🌀 Price: {card[4]:,} Chi\n\n"
        )

    text += (
        "━━━━━━━━━━━━━━\n"
        "🔄 Refreshes every 24 hours"
    )

    await message.reply(
        text,
        reply_markup=store_buttons(cards),
        parse_mode="HTML"
    )      

    # ------------------------
# Buy Daily Card
# ------------------------

@router.callback_query(
    lambda c: c.data.startswith("buy_daily_")
)
async def daily_buy_button(callback: CallbackQuery):

    store_id = int(
        callback.data.split("_")[2]
    )

    cursor.execute(
        """
        SELECT card_id, price
        FROM daily_store
        WHERE id = ?
        """,
        (store_id,)
    )

    item = cursor.fetchone()

    if not item:

        await callback.answer(
            "❌ This card is no longer available.",
            show_alert=True
        )

        return

    card_id = item[0]
    price = item[1]

    user_id = callback.from_user.id

    chi = get_chi(user_id)

    if chi < price:

        await callback.answer(
            f"❌ Not enough Chi!\nNeed {price:,} Chi",
            show_alert=True
        )

        return

    remove_chi(
        user_id,
        price
    )

    serial = add_card(
        user_id,
        card_id
    )

    cursor.execute(
        """
        SELECT
            name,
            rarity
        FROM cards
        WHERE id = ?
        """,
        (card_id,)
    )

    card = cursor.fetchone()

    cursor.execute(
        """
        DELETE FROM daily_store
        WHERE id = ?
        """,
        (store_id,)
    )

    conn.commit()

    await callback.message.answer(
        "✅ <b>Card Purchased!</b>\n\n"
        f"🎴 {card[0]}\n"
        f"⭐ {card[1]}\n"
        f"🔢 Serial: #{serial:06d}\n\n"
        f"🌀 Spent: {price:,} Chi",
        parse_mode="HTML"
    )

    await callback.answer()