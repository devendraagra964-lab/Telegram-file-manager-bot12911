from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder

import sqlite3


router = Router()


BURN_REWARDS = {

    "Common": 500,
    "Rare": 1000,
    "Epic": 2500,
    "Legendary": 5000,
    "Mythic": 15000,
    "Celestial": 30000

}



# =========================
# BUTTONS
# =========================

def burn_buttons(serial):

    keyboard = InlineKeyboardBuilder()

    keyboard.button(
        text="🔥 Confirm Burn",
        callback_data=f"confirm_burn_{serial}"
    )

    keyboard.button(
        text="❌ Cancel",
        callback_data="cancel_burn"
    )

    keyboard.adjust(2)

    return keyboard.as_markup()



# =========================
# /BURN
# =========================

@router.message(Command("burn"))
async def burn_command(message: Message):

    parts = message.text.split(maxsplit=1)


    if len(parts) < 2:

        await message.reply(
            "❌ Use:\n/burn <card name>"
        )

        return



    card_name = parts[1]

    user_id = message.from_user.id



    conn = sqlite3.connect(
        "otaku_arena.db"
    )

    cursor = conn.cursor()



    cursor.execute(
        """
        SELECT
            cards.name,
            cards.rarity,
            cards.rating,
            cards.image_id,
            inventory.serial_number

        FROM inventory

        JOIN cards

        ON inventory.card_id = cards.id

        WHERE inventory.telegram_id = ?

        AND LOWER(cards.name)=LOWER(?)

        LIMIT 1
        """,
        (
            user_id,
            card_name
        )
    )


    card = cursor.fetchone()


    conn.close()



    if not card:

        await message.reply(
            "❌ You don't own this card."
        )

        return



    name = card[0]
    rarity = card[1]
    rating = card[2]
    image = card[3]
    serial = card[4]



    await message.reply_photo(

        photo=image,

        caption=(
            "⚠️ <b>BURN CONFIRMATION</b> ⚠️\n\n"

            f"🎴 {name}\n"
            f"⭐ {rarity}\n"
            f"⚡ Rating: {rating}\n"
            f"🔢 Serial: #{serial:06d}\n\n"

            "🔥 This card will be permanently removed.\n"
            "Are you sure?"
        ),

        reply_markup=burn_buttons(serial),

        parse_mode="HTML"
    )



# =========================
# CONFIRM BURN
# =========================

@router.callback_query(
    F.data.startswith("confirm_burn_")
)
async def confirm_burn(callback: CallbackQuery):

    serial = int(
        callback.data.split("_")[2]
    )


    user_id = callback.from_user.id



    conn = sqlite3.connect(
        "otaku_arena.db"
    )

    cursor = conn.cursor()



    cursor.execute(
        """
        SELECT
            cards.name,
            cards.rarity

        FROM inventory

        JOIN cards

        ON inventory.card_id = cards.id

        WHERE inventory.telegram_id = ?

        AND inventory.serial_number = ?
        """,
        (
            user_id,
            serial
        )
    )


    card = cursor.fetchone()



    if not card:

        conn.close()

        await callback.answer(
            "❌ Card not found.",
            show_alert=True
        )

        return



    name = card[0]
    rarity = card[1]


    reward = BURN_REWARDS.get(
        rarity,
        100
    )



    cursor.execute(
        """
        DELETE FROM inventory

        WHERE telegram_id = ?

        AND serial_number = ?
        """,
        (
            user_id,
            serial
        )
    )



    cursor.execute(
        """
        UPDATE users

        SET chi = chi + ?

        WHERE telegram_id = ?
        """,
        (
            reward,
            user_id
        )
    )


    conn.commit()



    cursor.execute(
        """
        SELECT chi
        FROM users
        WHERE telegram_id = ?
        """,
        (
            user_id,
        )
    )


    balance = cursor.fetchone()[0]


    conn.close()



    await callback.message.edit_caption(

        caption=(
            "🔥 <b>CARD BURNED</b> 🔥\n\n"

            f"🎴 {name}\n"
            f"⭐ {rarity}\n\n"

            f"🌀 Received: +{reward:,} Chi\n"
            f"💰 Balance: {balance:,} Chi\n\n"

            "💀 The card has been sacrificed."
        ),

        parse_mode="HTML"
    )


    await callback.answer()



# =========================
# CANCEL
# =========================

@router.callback_query(
    F.data == "cancel_burn"
)
async def cancel_burn(callback: CallbackQuery):

    await callback.message.delete()

    await callback.answer(
        "❌ Burn cancelled."
    )