from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from aiogram.utils.keyboard import InlineKeyboardBuilder

from database.users import (
    get_user,
    get_card_count,
    get_daily_rolls
)

router = Router()


# =========================
# PROFILE BUTTONS
# =========================

def profile_buttons():

    keyboard = InlineKeyboardBuilder()

    keyboard.button(
        text="🎴 Collections",
        callback_data="profile_collections"
    )

    keyboard.button(
        text="🏪 Store",
        callback_data="profile_store"
    )

    keyboard.adjust(2)

    return keyboard.as_markup()


# =========================
# PROFILE COMMAND
# =========================

@router.message(Command("profile"))
async def profile_command(message: Message):

    user = get_user(message.from_user.id)

    if not user:

        await message.reply(
            "❌ You don't have an account.\n\nUse /start first."
        )
        return

    telegram_id = user[0]
    username = user[1]
    chi = user[2]
    total_rolls = user[3]
    daily_rolls = user[4]
    last_daily = user[5]
    join_date = user[6]

    cards = get_card_count(telegram_id)

    remaining_rolls = 5 - daily_rolls

    await message.reply(
        f"""
👤 <b>PLAYER PROFILE</b>

━━━━━━━━━━━━━━━━━━

🆔 <b>Username</b>
{username}

🌀 <b>Chi</b>
{chi:,}

🎲 <b>Total Rolls</b>
{total_rolls}

🎯 <b>Daily Rolls</b>
{daily_rolls}/5

🎟 <b>Remaining Today</b>
{remaining_rolls}

🎴 <b>Cards Owned</b>
{cards}

📅 <b>Joined Arena</b>
{join_date}

━━━━━━━━━━━━━━━━━━

💡 Keep rolling to unlock stronger cards and complete your collections!
""",
        parse_mode="HTML",
        reply_markup=profile_buttons()
    )


# =========================
# PROFILE BUTTONS
# =========================

@router.callback_query(lambda c: c.data == "profile_collections")
async def profile_collections(callback):

    await callback.answer(
        "💎 Use /collections to view your collection progress.",
        show_alert=True
    )


@router.callback_query(lambda c: c.data == "profile_store")
async def profile_store(callback):

    await callback.answer(
        "🏪 Use /store to open today's shop.",
        show_alert=True
    )