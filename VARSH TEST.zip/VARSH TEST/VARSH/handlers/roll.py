from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

import sqlite3
import random

from database.users import (
    get_chi,
    get_daily_rolls,
    can_roll,
    add_daily_roll,
    add_roll,
    remove_chi
)

from database.inventory import add_card
from database.collections import (
    get_available_rewards,
    reward_claimed,
    claim_reward
)


router = Router()


ROLL_COST = 1000
MAX_DAILY_ROLLS = 5


# ------------------------
# RARITY CHANCES
# ------------------------

RARITY_CHANCES = {
    "Common": 55,
    "Rare": 25,
    "Epic": 12,
    "Legendary": 6,
    "Mythic": 1.8,
    "Celestial": 0.2
}


@router.message(Command("roll"))
async def roll_command(message: Message):

    telegram_id = message.from_user.id


    # Daily Limit

    if not can_roll(telegram_id):

        await message.reply(
            "🚫 <b>Daily Roll Limit Reached!</b>\n\n"
            f"🎲 Daily Rolls: <b>{MAX_DAILY_ROLLS}/{MAX_DAILY_ROLLS}</b>\n\n"
            "Come back tomorrow after reset.",
            parse_mode="HTML"
        )

        return


    # Check Chi

    chi = get_chi(telegram_id)

    if chi < ROLL_COST:

        await message.reply(
            f"❌ Not enough Chi!\n\n"
            f"🌀 Required: {ROLL_COST:,}\n"
            f"🌀 Your Chi: {chi:,}"
        )

        return


    success = remove_chi(
        telegram_id,
        ROLL_COST
    )


    if not success:

        await message.reply(
            "❌ Roll failed."
        )

        return


    add_roll(telegram_id)
    add_daily_roll(telegram_id)



    db = sqlite3.connect(
        "otaku_arena.db"
    )

    cursor = db.cursor()


    # ------------------------
    # Roll Rarity
    # ------------------------

    rarity = random.choices(
        list(RARITY_CHANCES.keys()),
        weights=list(RARITY_CHANCES.values())
    )[0]


    # ------------------------
    # Get Cards Of That Rarity
    # ------------------------

    cursor.execute(
        """
        SELECT
            id,
            name,
            series,
            rarity,
            rating,
            image_id

        FROM cards

        WHERE rarity = ?
        """,
        (rarity,)
    )


    cards = cursor.fetchall()



    # Safety if rarity has no cards

    if not cards:

        cursor.execute(
            """
            SELECT
                id,
                name,
                series,
                rarity,
                rating,
                image_id

            FROM cards
            """
        )

        cards = cursor.fetchall()



    db.close()



    if not cards:

        await message.reply(
            "❌ No cards available."
        )

        return



    # Pick card

    card = random.choice(cards)



    serial = add_card(
        telegram_id,
        card[0]
    )



    # ------------------------
    # Collection Rewards
    # ------------------------

    rewards = get_available_rewards(
        telegram_id,
        card[2]
    )


    reward_text = ""


    for reward in rewards:

        reward_id = reward[0]
        required = reward[1]
        reward_chi = reward[2]
        title = reward[3]


        if not reward_claimed(
            telegram_id,
            reward_id
        ):

            claim_reward(
                telegram_id,
                reward_id,
                reward_chi
            )


            reward_text += (
                "\n\n🏆 <b>Collection Reward Unlocked!</b>\n"
                f"🎴 {card[2]} Collection\n"
                f"📚 {required} Cards Collected\n"
                f"👑 Title: <b>{title}</b>\n"
                f"🌀 Reward: +{reward_chi:,} Chi"
            )



    remaining_chi = get_chi(
        telegram_id
    )


    used_rolls = get_daily_rolls(
        telegram_id
    )


    remaining_rolls = MAX_DAILY_ROLLS - used_rolls



    await message.reply_photo(

        photo=card[5],

        caption=(

            "🎉 <b>You Rolled a Card!</b>\n\n"

            f"🃏 <b>{card[1]}</b>\n"
            f"📺 Series: <b>{card[2]}</b>\n"
            f"⭐ Rarity: <b>{card[3]}</b>\n"
            f"⚡ Rating: <b>{card[4]}</b>\n"
            f"🔢 Serial: <b>#{serial:06d}</b>\n\n"

            f"🎲 Daily Rolls: <b>{used_rolls}/{MAX_DAILY_ROLLS}</b>\n"
            f"🎟 Remaining Today: <b>{remaining_rolls}</b>\n"
            f"🌀 Chi Left: <b>{remaining_chi:,}</b>"

            f"{reward_text}"

        ),

        parse_mode="HTML"

    )