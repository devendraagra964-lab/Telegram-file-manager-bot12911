from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from database.database import cursor

router = Router()


# ------------------------
# Get User Collections
# ------------------------

def get_collections(user_id):
    cursor.execute(
        """
        SELECT
            cards.series,
            COUNT(DISTINCT cards.id)
        FROM inventory
        JOIN cards
        ON inventory.card_id = cards.id
        WHERE inventory.telegram_id = ?
        GROUP BY cards.series
        ORDER BY cards.series
        """,
        (user_id,)
    )

    return cursor.fetchall()


# ------------------------
# Get Total Cards In Series
# ------------------------

def get_total_cards(series):
    cursor.execute(
        """
        SELECT COUNT(*)
        FROM cards
        WHERE series = ?
        """,
        (series,)
    )

    return cursor.fetchone()[0]


# ------------------------
# Get All Rewards For Series
# ------------------------

def get_series_rewards(series):
    cursor.execute(
        """
        SELECT
            id,
            required_cards,
            reward_chi,
            reward_title
        FROM collection_rewards
        WHERE series = ?
        ORDER BY required_cards
        """,
        (series,)
    )

    return cursor.fetchall()


# ------------------------
# Check Claimed Reward
# ------------------------

def is_reward_claimed(user_id, reward_id):
    cursor.execute(
        """
        SELECT 1
        FROM claimed_rewards
        WHERE telegram_id = ?
        AND reward_id = ?
        """,
        (user_id, reward_id)
    )

    return cursor.fetchone() is not None


# ------------------------
# Collections Command
# ------------------------

@router.message(Command("collections"))
async def collections_command(message: Message):

    user_id = message.from_user.id

    collections = get_collections(user_id)

    if not collections:

        await message.reply(
            "🏆 Your collection is empty.\n\n"
            "Roll cards to start collecting!"
        )

        return

    text = (
        f"🏆 <b>{message.from_user.first_name}'s Collections</b>\n"
        "━━━━━━━━━━━━━━\n\n"
    )

    for series, count in collections:

        total = get_total_cards(series)

        text += (
            f"📺 <b>{series}</b>\n"
            f"🎴 Progress: {count}/{total}\n\n"
        )

        rewards = get_series_rewards(series)

        if rewards:

            for reward in rewards:

                reward_id = reward[0]
                required = reward[1]
                chi = reward[2]
                title = reward[3]

                if is_reward_claimed(user_id, reward_id):
                    status = "✅ CLAIMED"

                elif count >= required:
                    status = "🎁 UNLOCKED"

                else:
                    status = "🔒 LOCKED"

                text += (
                    f"{status}\n"
                    f"🎴 {required} Cards\n"
                    f"🌀 {chi:,} Chi\n"
                    f"👑 {title}\n\n"
                )

        else:

            text += "❌ No rewards configured.\n\n"

        text += "━━━━━━━━━━━━━━\n\n"

    await message.reply(
        text,
        parse_mode="HTML"
    )